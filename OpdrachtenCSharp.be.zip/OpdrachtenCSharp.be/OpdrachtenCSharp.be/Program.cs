﻿using System;

namespace OpdrachtenCSharp.be
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Made by Ivan Cheng.");
            Console.WriteLine("Klas: AI 145.");
            Console.WriteLine("Made on 03-06-2021.");
            Console.WriteLine("______________________________________________________________________________________");
            StartOpdrachten();
            

        }


        public static void StartOpdrachten()
        {
            //variabelen
            int iAntwoordVraag;

            // Vraag welke opdracht u wilt zien
            Console.WriteLine("Naar welke opdracht wilt u gaan?");
            Console.WriteLine("1: Opdracht 3-1 van c-sharp.be");
            
            Console.WriteLine("2: Opdracht 3-2 van c-sharp.be");
            
            Console.WriteLine("3: Opdracht 3-3 van c-sharp.be");
            
            Console.WriteLine("4: Opdracht 3-4 van c-sharp.be");
            
            Console.WriteLine("5: Opdracht 3-5 van c-sharp.be");

            Console.WriteLine("6: Opdracht 3-6 van c-sharp.be");

            Console.WriteLine("7: Ga naar page 2");

            Console.WriteLine("");

            Console.WriteLine("Page 1/3");

            string sAntwoordVraag = Console.ReadLine();
            iAntwoordVraag = Int32.Parse(sAntwoordVraag);
            // Switch Case voor opdrachten -------------------------------------------------------------------------
            switch (iAntwoordVraag)
            {
                case 1:
                    Console.Clear();
                    UitrekenenAB();
                    break;

                case 2:
                    Console.Clear();
                    UitrekenenEindKapitaal();
                    break;

                case 3:
                    Console.Clear();
                    VerjaardagBerekenen();
                    break;

                case 4:
                    Console.Clear();
                    WachtWoordGenerator();
                    break;

                case 5:
                    Console.Clear();
                    AlfabetischeVOlgordeNamen();
                    break;
                case 6:
                    Console.Clear();
                    OpdrachtGootsteGetal();
                    break;
                case 7:
                    Console.Clear();
                    Page2();
                    break;

            }
        }

        //Opdrachten op Page 2 --------------------------------------------------------------------------------------------
        public static void Page2()
        {
            //variabelen
            int iAntwoordVraag;

            // Vraag welke opdracht u wilt zien
            Console.WriteLine("Naar welke opdracht wilt u gaan?");
            Console.WriteLine("1: Opdracht Geeks4Geeks maximum area");

            Console.WriteLine("2: Opdracht Array 14-9-2021");

            Console.WriteLine("3: Opdracht C# Iteratie niveau 1");

            Console.WriteLine("4:");

            Console.WriteLine("5: ");

            Console.WriteLine("6: ");

            Console.WriteLine("7: Ga naar page 3 (Page 3 bestaat nog niet)");

            Console.WriteLine("8: Ga naar page 1");

            Console.WriteLine("");

            Console.WriteLine("Page 2/3");

            string sAntwoordVraag = Console.ReadLine();
            iAntwoordVraag = Int32.Parse(sAntwoordVraag);
            switch (iAntwoordVraag)
            {
                case 1:
                    Console.Clear();
                    MaximumArea();
                    break;

                case 2:
                    Console.Clear();
                    ArrayOpdrachtCs();
                    break;

                case 3:
                    Console.Clear();
                    Iteratie1();
                    break;

                case 4:
                    Console.Clear();
                    ;
                    break;

                case 5:
                    Console.Clear();
                    ;
                    break;
                case 6:
                    Console.Clear();
                    ;
                    break;
                case 7:
                    Console.Clear();
                    ; //hier komt manier om naar page 3 te gaan
                    break;
                case 8:
                    Console.Clear();
                    StartOpdrachten();
                    break;
            }
        }
        // Start uitrekenen zijde AB (opdracht 3-1) -------------------------------------------------------------------------
        public static void UitrekenenAB()
        {
            // Variabelen
            double dHoekA;
            double dHoekC;
            double dZijdeAB;
            double dZijdeAC;

            // Input Getallen hoek C
            Console.WriteLine("Hoeveel graden is hoek C?");
            string sHoekC = Console.ReadLine();
            // Verandert string naar double
            dHoekC = Int32.Parse(sHoekC);
            // Hoek C naar radialen
            double dHoekCRadialen = dHoekC * Math.PI / 180;


            // Input Getallen hoek A
            Console.WriteLine("Hoeveel graden is hoek A?");
            string sHoekA = Console.ReadLine();
            // Verandert string naar double
            dHoekA = Int32.Parse(sHoekC);
            // Hoek A naar radialen
            double dHoekARadialen = dHoekA * Math.PI / 180;


            // Input Getallen zijde AC
            Console.WriteLine("Hoeveel lang is zijde AC?");
            string sZijdeAC = Console.ReadLine();
            // Verandert string naar double
            dZijdeAC = Int32.Parse(sHoekC);


            // Berekenen zijde AB
            dZijdeAB = dZijdeAC * (Math.Sin(dHoekCRadialen) / Math.Sin(dHoekARadialen + dHoekCRadialen));


            // Antwoord wordt laten zien
            Console.WriteLine($"Zijde AB = {Math.Round(dZijdeAB, 1)}");
            Console.ReadLine();
            // cleart Console
            Console.Clear();
            StartOpdrachten();
        }


        // Start Uitrekenen eind kapitaal (opdracht 3-2) -------------------------------------------------------------------------
        public static void UitrekenenEindKapitaal()
        {
            // Variabelen
            double dBeginKapitaal;
            double dEindKapitaal;
            double dInterestVoet = 0.0125;
            int iLoopTijd;

            // Input begin kapitaal
            Console.WriteLine("Wat is uw begin kapitaal");
            string sBeginKapitaal = Console.ReadLine();
            dBeginKapitaal = Int32.Parse(sBeginKapitaal);

            // Input looptijd
            Console.WriteLine("Wat is uw looptijd");
            string sLoopTijd = Console.ReadLine();
            iLoopTijd = Int32.Parse(sLoopTijd);

            // Clear console
            Console.Clear();

            // Berekenen eind kapitaal
            dEindKapitaal = Math.Pow((1 + dInterestVoet), iLoopTijd) * dBeginKapitaal;

            // Antwoord wordt laten zien
            Console.WriteLine(dEindKapitaal);
            Console.ReadLine();
            // Clear Console
            Console.Clear();
            StartOpdrachten();
        }

        // Start VerjaardagBerekenen (opdracht 3-3) -------------------------------------------------------------------------
        public static void VerjaardagBerekenen()
        {
            // Mijn verjaardag
            DateTime birthday = new DateTime(2003,5,14);
            // Datum en tijd van vandaag
            DateTime today = DateTime.Today;
            // Er wordt zoveel jaren erbij gedaan zodat de jaren evenveel zijn
            DateTime next = birthday.AddYears(today.Year - birthday.Year);

            // Als de datum van vandaag groter is dan je verjaardag dan wordt er 1 jaar toegevoegd
            if (next < today)
                next = next.AddYears(1);

            // Hier wordt berekend hoeveel dagen het nog duurt tot je volgende verjaardag
            int numDays = (next - today).Days;
            // Antwoord wordt hier laten zien
            Console.WriteLine(numDays);
            Console.ReadLine();
            // Clear Console
            Console.Clear();
            StartOpdrachten();
        }

        // Start Wachtwoord generator (opdracht 3-4) -------------------------------------------------------------------------
        public static void WachtWoordGenerator()
        {
            // Input eerste letter achternaam
            Console.WriteLine("Wat is het eerste letter van uw achternaam?");
            string sEersteLetterLastName = Console.ReadLine().ToUpper();

            // Input tweede letter achternaam
            Console.WriteLine("Wat is het tweede letter van uw achternaam?");
            string sTweedeLetterLastName = Console.ReadLine().ToLower();

            // Input postcode
            Console.WriteLine("Wat is het eerste cijfer van uw postcode?");
            string sPostalCode = Console.ReadLine();
            int iPostalCode = Int32.Parse(sPostalCode);

            // Input zonenummer of netnummer
            Console.WriteLine("Wat is uw netnummer of zonenummer zonder de eerste 0?");
            string sNetNumber = Console.ReadLine();

            double iPostalcodePow = Math.Pow(iPostalCode,2);

            Console.WriteLine($"Uw wachtwoord is: {sTweedeLetterLastName}{sEersteLetterLastName}{iPostalcodePow}{sNetNumber}");
            Console.ReadLine();
            // Clear Console
            Console.Clear();
            // Je gaat terug naar het keuze meu
            StartOpdrachten();
        }

        // Start AlfabetischeVorlgordeNamen (Opdracht 3-5) -------------------------------------------------------------------------
        public static void AlfabetischeVOlgordeNamen()
        {
            // String array
            string[] aNamen = new string[2];
            Console.WriteLine("Geef 2 namen");
            // Als i < dan hoeveelheid strings in array dan blijft het loopen
            for (int i = 0; i < aNamen.Length; i++)
            {
                aNamen[i] = Console.ReadLine();
            }
            // Array wordt gesorteerd
            Array.Sort(aNamen);
            // Console wordt gecleart
            Console.Clear();
            // Namen worden weer laten zien
            foreach (string i in aNamen)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
            // Clear Console
            Console.Clear();
            StartOpdrachten();
        }

        // Start opdracht 3-6 --------------------------------------------------------------------------------

        public static void OpdrachtGootsteGetal()
        {

            
            // Variabelen
            int iGetal1;
            int iGetal2;
            // Vraag 2 getallen
            Console.WriteLine("Kies een getal");
            string sGetal1 = Console.ReadLine();
            iGetal1 = Int32.Parse(sGetal1);
            Console.WriteLine("Kies een tweede getal");
            string sGetal2 = Console.ReadLine();
            iGetal2 = Int32.Parse(sGetal2);

            // als getal 1 kleiner is dan getal 2 dan staat getal 1 laatst en andersom
            if (iGetal1 < iGetal2)
            {
                Console.WriteLine($"{iGetal2} {iGetal1}");
            }
            else if (iGetal1 > iGetal2)
            {
                Console.WriteLine($"{iGetal1} {iGetal2}");
            }
            Console.ReadLine();
            Console.Clear();
            StartOpdrachten();
        }

        // Start Opdracht 3-7 ------------------------------------------------------------------------------------

        public static void Opdracht7H3()
        {

        }

        // Geeks4Geeks Maximum area opdracht ----------------------------------------------------------------------

        public static void MaximumArea()
        {
            int oppdriehoek;
            double lengtedriehoek;
            double schuinezijde;

            Console.WriteLine("Wat is de opp van de driehoek?");
            string OppDrieHoek = Console.ReadLine();
            oppdriehoek = Convert.ToInt32(OppDrieHoek);

            lengtedriehoek = oppdriehoek * 4;
            schuinezijde = Math.Sqrt(lengtedriehoek);
            Console.Clear();
            Console.WriteLine($"uw schuinezijde is { schuinezijde }");
            Console.ReadLine();
            StartOpdrachten();
        }

        // Array opdracht van 14-09-2021 ----------------------------------------------------------------------------

        public static void ArrayOpdrachtCs()
        {
            string[] answer = new string[4];
            for (int i = 0; i < answer.Length; i++)
            {
                answer[i] = Console.ReadLine();
            }
            Console.Clear();

            Console.ReadLine();
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine(answer[i]);
            }
            StartOpdrachten();
        }

        // Opdracht C# Iteratie niveau 1 ------------------------------------------------------------------------

        public static void Iteratie1()
        {
            Console.WriteLine("Hoeveel sterren wilt u?");
            string sPatroonAantal = Console.ReadLine();
            int iPatroonAantal = Convert.ToInt32(sPatroonAantal);
            for (int i = 0; i < iPatroonAantal; i++)
            {
                for (int a = 0; a < i; a++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            StartOpdrachten();
        }

    }
}
